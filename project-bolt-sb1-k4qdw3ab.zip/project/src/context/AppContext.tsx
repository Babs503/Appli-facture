import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  Client, 
  Product, 
  Invoice, 
  Quote, 
  Payment, 
  User, 
  AppSettings 
} from '../types';
import { 
  clients as mockClients, 
  products as mockProducts, 
  invoices as mockInvoices,
  quotes as mockQuotes,
  payments as mockPayments,
  users as mockUsers,
  appSettings as mockSettings
} from '../data/mockData';
import { generateInvoiceNumber, generateQuoteNumber, quoteToInvoice } from '../utils/format';

interface AppContextType {
  // Data
  clients: Client[];
  products: Product[];
  invoices: Invoice[];
  quotes: Quote[];
  payments: Payment[];
  users: User[];
  settings: AppSettings;
  currentUser: User | null;

  // Client operations
  addClient: (client: Omit<Client, 'id' | 'createdAt'>) => void;
  updateClient: (id: string, client: Partial<Client>) => void;
  deleteClient: (id: string) => void;
  getClientById: (id: string) => Client | undefined;

  // Product operations
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  getProductById: (id: string) => Product | undefined;

  // Invoice operations
  addInvoice: (invoice: Omit<Invoice, 'id' | 'createdAt' | 'number'>) => void;
  updateInvoice: (id: string, invoice: Partial<Invoice>) => void;
  deleteInvoice: (id: string) => void;
  getInvoiceById: (id: string) => Invoice | undefined;

  // Quote operations
  addQuote: (quote: Omit<Quote, 'id' | 'createdAt' | 'number'>) => void;
  updateQuote: (id: string, quote: Partial<Quote>) => void;
  deleteQuote: (id: string) => void;
  getQuoteById: (id: string) => Quote | undefined;
  convertQuoteToInvoice: (quoteId: string) => string | undefined; // Returns the new invoice ID

  // Payment operations
  addPayment: (payment: Omit<Payment, 'id' | 'createdAt'>) => void;
  updatePayment: (id: string, payment: Partial<Payment>) => void;
  deletePayment: (id: string) => void;
  getPaymentById: (id: string) => Payment | undefined;
  getPaymentsByInvoiceId: (invoiceId: string) => Payment[];

  // Authentication
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  
  // Settings
  updateSettings: (settings: Partial<AppSettings>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // State for all data
  const [clients, setClients] = useState<Client[]>(mockClients);
  const [products, setProducts] = useState<Product[]>(mockProducts);
  const [invoices, setInvoices] = useState<Invoice[]>(mockInvoices);
  const [quotes, setQuotes] = useState<Quote[]>(mockQuotes);
  const [payments, setPayments] = useState<Payment[]>(mockPayments);
  const [users, setUsers] = useState<User[]>(mockUsers);
  const [settings, setSettings] = useState<AppSettings>(mockSettings);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Initialize with mock data or load from localStorage
  useEffect(() => {
    // In a real app, we would load data from API or localStorage here
    // For demo, we're using the mock data initialized above
    
    // Auto login for demonstration
    setCurrentUser(users[0]);
  }, []);

  // Client operations
  const addClient = (client: Omit<Client, 'id' | 'createdAt'>) => {
    const newClient: Client = {
      ...client,
      id: Math.random().toString(36).substring(2, 10),
      createdAt: new Date()
    };
    setClients([...clients, newClient]);
  };

  const updateClient = (id: string, client: Partial<Client>) => {
    setClients(clients.map(c => c.id === id ? { ...c, ...client } : c));
  };

  const deleteClient = (id: string) => {
    setClients(clients.filter(c => c.id !== id));
  };

  const getClientById = (id: string) => {
    return clients.find(c => c.id === id);
  };

  // Product operations
  const addProduct = (product: Omit<Product, 'id' | 'createdAt'>) => {
    const newProduct: Product = {
      ...product,
      id: Math.random().toString(36).substring(2, 10),
      createdAt: new Date()
    };
    setProducts([...products, newProduct]);
  };

  const updateProduct = (id: string, product: Partial<Product>) => {
    setProducts(products.map(p => p.id === id ? { ...p, ...product } : p));
  };

  const deleteProduct = (id: string) => {
    setProducts(products.filter(p => p.id !== id));
  };

  const getProductById = (id: string) => {
    return products.find(p => p.id === id);
  };

  // Invoice operations
  const addInvoice = (invoice: Omit<Invoice, 'id' | 'createdAt' | 'number'>) => {
    const invoiceNumber = generateInvoiceNumber('FACT', invoices.map(i => i.number));
    const newInvoice: Invoice = {
      ...invoice,
      id: Math.random().toString(36).substring(2, 10),
      number: invoiceNumber,
      createdAt: new Date()
    };
    setInvoices([...invoices, newInvoice]);
  };

  const updateInvoice = (id: string, invoice: Partial<Invoice>) => {
    setInvoices(invoices.map(i => i.id === id ? { ...i, ...invoice } : i));
  };

  const deleteInvoice = (id: string) => {
    setInvoices(invoices.filter(i => i.id !== id));
  };

  const getInvoiceById = (id: string) => {
    return invoices.find(i => i.id === id);
  };

  // Quote operations
  const addQuote = (quote: Omit<Quote, 'id' | 'createdAt' | 'number'>) => {
    const quoteNumber = generateQuoteNumber('DEV', quotes.map(q => q.number));
    const newQuote: Quote = {
      ...quote,
      id: Math.random().toString(36).substring(2, 10),
      number: quoteNumber,
      createdAt: new Date()
    };
    setQuotes([...quotes, newQuote]);
  };

  const updateQuote = (id: string, quote: Partial<Quote>) => {
    setQuotes(quotes.map(q => q.id === id ? { ...q, ...quote } : q));
  };

  const deleteQuote = (id: string) => {
    setQuotes(quotes.filter(q => q.id !== id));
  };

  const getQuoteById = (id: string) => {
    return quotes.find(q => q.id === id);
  };

  const convertQuoteToInvoice = (quoteId: string) => {
    const quote = getQuoteById(quoteId);
    if (!quote) return undefined;

    const invoiceNumber = generateInvoiceNumber('FACT', invoices.map(i => i.number));
    const newInvoice = quoteToInvoice(quote, invoiceNumber);
    
    setInvoices([...invoices, newInvoice]);
    updateQuote(quoteId, { status: 'converted' });
    
    return newInvoice.id;
  };

  // Payment operations
  const addPayment = (payment: Omit<Payment, 'id' | 'createdAt'>) => {
    const newPayment: Payment = {
      ...payment,
      id: Math.random().toString(36).substring(2, 10),
      createdAt: new Date()
    };
    setPayments([...payments, newPayment]);
    
    // Update invoice status if fully paid
    const invoice = getInvoiceById(payment.invoiceId);
    if (invoice) {
      const invoicePayments = [...payments, newPayment].filter(p => p.invoiceId === payment.invoiceId);
      const totalPaid = invoicePayments.reduce((sum, p) => sum + p.amount, 0);
      
      if (totalPaid >= invoice.total) {
        updateInvoice(invoice.id, { status: 'paid' });
      }
    }
  };

  const updatePayment = (id: string, payment: Partial<Payment>) => {
    setPayments(payments.map(p => p.id === id ? { ...p, ...payment } : p));
  };

  const deletePayment = (id: string) => {
    const payment = getPaymentById(id);
    if (!payment) return;
    
    setPayments(payments.filter(p => p.id !== id));
    
    // Update invoice status if needed
    const invoice = getInvoiceById(payment.invoiceId);
    if (invoice && invoice.status === 'paid') {
      const remainingPayments = payments.filter(p => p.invoiceId === payment.invoiceId && p.id !== id);
      const totalPaid = remainingPayments.reduce((sum, p) => sum + p.amount, 0);
      
      if (totalPaid < invoice.total) {
        updateInvoice(invoice.id, { status: 'sent' });
      }
    }
  };

  const getPaymentById = (id: string) => {
    return payments.find(p => p.id === id);
  };

  const getPaymentsByInvoiceId = (invoiceId: string) => {
    return payments.filter(p => p.invoiceId === invoiceId);
  };

  // Authentication
  const login = async (email: string, password: string): Promise<boolean> => {
    // In a real app, we would call an API here
    // For demo, just check if the user exists
    const user = users.find(u => u.email === email);
    if (user) {
      setCurrentUser(user);
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
  };

  // Settings
  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings({ ...settings, ...newSettings });
  };

  return (
    <AppContext.Provider
      value={{
        clients,
        products,
        invoices,
        quotes,
        payments,
        users,
        settings,
        currentUser,
        
        addClient,
        updateClient,
        deleteClient,
        getClientById,
        
        addProduct,
        updateProduct,
        deleteProduct,
        getProductById,
        
        addInvoice,
        updateInvoice,
        deleteInvoice,
        getInvoiceById,
        
        addQuote,
        updateQuote,
        deleteQuote,
        getQuoteById,
        convertQuoteToInvoice,
        
        addPayment,
        updatePayment,
        deletePayment,
        getPaymentById,
        getPaymentsByInvoiceId,
        
        login,
        logout,
        
        updateSettings
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};